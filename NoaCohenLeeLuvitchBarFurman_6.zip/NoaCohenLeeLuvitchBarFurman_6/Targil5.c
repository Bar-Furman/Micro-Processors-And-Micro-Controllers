/**********************************************************************
 * Tittle: TARGIL5
 * Filename: Targil5.c *
 * File Version: 1.0 *
 * *
 * */
#include "DSP28x_Project.h" // Device Header file and Examples Include File
/*****************************************************************************/
#include "LCD.h"
#include "GPIO.h"





typedef enum {IDLE, RUN, WAIT} StateMachinetype;
static StateMachinetype MyStateMachine = IDLE;
int mycounter =0;

void RunStateMachine(int start, int stop)
	   {
	      int a;
	       int b;
		   char str[16] = "counter =       ";
		   BackLightLCD(1);
		   ClearLCD();

		   switch(MyStateMachine)
		   {
		   case IDLE:
			   ClearLCD();
			   if(start==1)
			   		MyStateMachine = RUN;
			   mycounter =0;
			   GpioDataRegs.GPCDAT.bit.GPIO65 =0;
			   GpioDataRegs.GPCDAT.bit.GPIO66 =0;
			   GpioDataRegs.GPCTOGGLE.bit.GPIO64 = 1;
			   PrintLCD("IDLE");
			   str[10] = 0+ '0';
			   str[11] = 0 + '0';
			   GoToLCD(1, 0);
			   PrintLCD(str);
			   //DELAY_US(100000);
			   break;
		   case RUN:
			   ClearLCD();
			   if(stop ==1)
						MyStateMachine = WAIT;
			   mycounter++;
			   PrintLCD("RUN");
			   a = mycounter %10;
			   b = mycounter /10;
			   str[10] = b + '0';
			   str[11] = a + '0';
			   GoToLCD(1, 0);
			   PrintLCD(str);
			   GpioDataRegs.GPCDAT.bit.GPIO64 =0;
			   GpioDataRegs.GPCDAT.bit.GPIO66 =0;
			   GpioDataRegs.GPCTOGGLE.bit.GPIO65 = 1;
			  // DELAY_US(100000);
			   GpioDataRegs.GPCDAT.bit.GPIO65 =0;
			   //DELAY_US(100000);

			   /*
			   while(stop ==1)
			   {
				   GpioDataRegs.GPCDAT.bit.GPIO65 =0;
				   DELAY_US(100000);
				   GpioDataRegs.GPCDAT.bit.GPIO65 =1;
				   DELAY_US(100000);
				   int stop = GpioDataRegs.GPCDAT.bit.GPIO81;
				   if(stop ==0)
				 			MyStateMachine = WAIT;
			   }
			   */
			   break;
		   case WAIT:
			   ClearLCD();
			   GpioDataRegs.GPCDAT.bit.GPIO64 =0;
			   GpioDataRegs.GPCDAT.bit.GPIO65 =0;
			   GpioDataRegs.GPCTOGGLE.bit.GPIO66 = 1;
			   if(start ==1)
				   MyStateMachine = RUN;
			   else if (stop ==1)
				   MyStateMachine = IDLE;
			   PrintLCD("WAIT");
			   a = mycounter %10;
			  b = mycounter /10;
			  str[10] = b + '0';
			  str[11] = a + '0';
			  GoToLCD(1, 0);
			  PrintLCD(str);
			   //DELAY_US(100000);
			   break;

		   }
		   }




