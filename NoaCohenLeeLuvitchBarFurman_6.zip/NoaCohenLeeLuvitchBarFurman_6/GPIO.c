/**********************************************************************
 * Tittle: Delfino Evaluation Board LCD 2x16 Display *
 * Filename: LCD2x16Display.c *
 * Date: 20-11-2014 *
 * Last Modify: 20-11-2014 *
 * File Version: 1.0 *
 * *
 * Author: Flaxer Eli *
 * Company: Flaxer.net *
 * *
 * */
#include "DSP28x_Project.h" // Device Header file and Examples Include File
/*****************************************************************************/
#include "LCD.h"



/*****************************************************************************/
void GpioCSetClear(int k,int x) //this function check if the value in x is 1 - and if true it sets the values of port C to (1L<<k) (shift left the amount of k)
//and if not it CLEARS the value in port C using the mask (1L<<k)
{
	if (x)
		GpioDataRegs.GPCSET.all = (1L<<k);
	else
		GpioDataRegs.GPCCLEAR.all = (1L<<k);
}
/*****************************************************************************/
void DelfinoEvbGpioSelect(void)
{
    EALLOW;

	GpioCtrlRegs.GPAMUX1.all = 0x00000000;  	// All GPIO
	GpioCtrlRegs.GPAMUX2.all = 0x00000000;  	// All GPIO

    GpioCtrlRegs.GPADIR.all = 0x0000000F;   	// Outputs 4 Leds
    GpioCtrlRegs.GPADIR.bit.GPIO27 = 1;   		// Buzzer
    GpioCtrlRegs.GPBDIR.all = 0x07FF0000;   	// Outputs LCD 8 Bus 3 Control
    //GpioCtrlRegs.GPBDIR.all = 0x07FF??00;   	// Extended Bus Direction GPIO40-GPIO47 KB
    GpioCtrlRegs.GPCDIR.all = 0x0000FFFF;   	// Outputs 8 Leds 4 TP 4 TestLed
    //GpioCtrlRegs.GPCDIR.all = 0x000?FFFF;   	// Extended Bus Direction GPIO80-GPIO83 Button

    //GpioCtrlRegs.GPBPUD.all = 0x0000FF00;   	// Extended Bus Pull-Up Resistors

    EDIS;
}


