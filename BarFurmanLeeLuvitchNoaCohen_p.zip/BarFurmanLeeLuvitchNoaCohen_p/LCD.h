
//###########################################################################
//
// FILE:   LCD2x16Display.h
//
// TITLE:  LCD text 2x16 Display
//
//###########################################################################

#ifndef LCD_H
#define LCD_H //define the file

extern void PrintLCD(const char *str); //extern the function PrintLCD from LCD.c
extern void InItLCD(void); //extern the function InItLCD from LCD.c
extern void ClearLCD(void); //extern the function ClearLCD from LCD.c
extern void BackLightLCD(int x); //extern the function BackLightLCD from LCD.c
extern void PutcLCD(const char c); //extern the function PutcLCD from LCD.c
extern void GoToLCD(char y, char x); //extern the function GoToLCD from LCD.c

#endif  // end of LCD2x16DISPLAY_H definition

