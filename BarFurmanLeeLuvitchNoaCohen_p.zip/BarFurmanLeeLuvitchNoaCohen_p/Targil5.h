
//###########################################################################
//
// FILE:   LCD2x16Display.h
//
// TITLE:  LCD text 2x16 Display
//
//###########################################################################

#ifndef Targil5_H
#define Targil5_H //define the file

extern void Targil4(void); //extern the function Targil4 from Targil4.c
extern void RunStateMachine(int start, int stop);
int CodeSystem(int flag);


#endif  // end of LCD2x16DISPLAY_H definition

