
//###########################################################################
//
// FILE:   KeyboardMat4x4.h
//
// TITLE:  LCD text 2x16 Display
//
//###########################################################################

#ifndef KeyboardMat4x4_H
#define KeyboardMat4x4_H //define the file

inline static void KeboardWriteCode(char data);
inline static char KeboardReadCode();
extern inline void Beep(int MiliSec);
char scan2ascii(char sc);
extern char ReadKB(char wait);
extern char PushButtonRead(int Inx);
extern void ConfigAndInstallKBInt();
extern interrupt void Xint3456_isr(void);

#endif  // end of LCD2x16DISPLAY_H definition

