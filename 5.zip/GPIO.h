
//###########################################################################
//
// FILE:   LCD2x16Display.h
//
// TITLE:  LCD text 2x16 Display
//
//###########################################################################

#ifndef GPIO_H
#define GPIO_H

extern void DelfinoEvbGpioSelect(void); //extern the function DelfinoEvbGpioSelect from GPIO.c
extern void MyMainProg(void); //extern the function MyMainProg from GPIO.c

#endif  // end of LCD2x16DISPLAY_H definition

